# Self-guided Knowledgeable Network-of-Thought
source code for AAAI submission #6100

## Usage

Prompts are stored in prompt.py.

If you want to run code, you can use script.py to run the example. The following is an example:

```python
python3 script.py --dataset data/add/add_08.csv --record record.txt
```

## Illustration

![image](https://anonymous.4open.science/r/kNoT-5048/image/compare2.jpg)

![image](https://anonymous.4open.science/r/kNoT-5048/image/illustration2.jpg)


